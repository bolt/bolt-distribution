Bolt
====

Sophisticated, lightweight & simple CMS, based on [Silex](http://silex.sensiolabs.org/). 

Installation: 

Create a new folder, and clone from github. Then use composer to get the Silex micro-framework and components:

    git clone git://github.com/bobdenotter/bolt.git bolt
    cd bolt 
    curl -s http://getcomposer.org/installer | php
    php composer.phar install

And you're good to go.

More detailed instructions can be found in the [Setup section in the documentation](http://docs.bolt.cm/setup).
