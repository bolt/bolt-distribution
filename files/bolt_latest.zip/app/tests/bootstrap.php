<?php

/*
 * Test bootstrapper. This leaves out all stuff registering services and
 * related to request dispatching.
 */

require_once __DIR__.'/../../vendor/autoload.php';