Google Analytics
================

This extension inserts the Google Analitics tracker code in your pages. Edit the `config.yml` file so
it contains the correct 'webproperty-id'.
