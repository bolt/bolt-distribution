Facebook Like Button
====================

The "Facebook Like Button" is a small extension to insert a Facebook Like Button
in your templates. Use it by simply placing the following in your template:

    {{ facebooklike() }}

