Facebook Comments
=================

The "Facebook Comments" extension inserts a Facebook comment thread
in your templates. Use it by simply placing the following in your template:

    {{ facebookcomments() }}

To include the current page's title, pass it as a parameter:

    {{ facebookcomments( record.title ) }}

