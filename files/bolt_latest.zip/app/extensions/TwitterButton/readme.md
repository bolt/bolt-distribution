Twitter Button
==============

The "Twitter Button" is a small extension to insert a Twitter Button
in your templates. Use it by simply placing the following in your template:

    {{ twitterbutton() }}


